<?php
$host = "sql303.epizy.com";
$user = "epiz_23980227";
$pass = "okkygaul123";
$db = "epiz_23980227_jogjastore";

$koneksi = mysqli_connect($host,$user,$pass,$db);

if (mysqli_connect_error()){
	
	echo "Gagal Koneksi".mysqli_connect_error();
}
?>